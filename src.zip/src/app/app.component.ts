import { Component, ViewChild } from '@angular/core';
import { DataService } from './data-ser.service';
import { trigger, state, style, transition, animate, keyframes } from '@angular/animations';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';


 
import {Http} from '@angular/http';
import { FacebookService, LoginResponse, LoginOptions, UIResponse, UIParams, FBVideoComponent } from 'ngx-facebook';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})



export class AppComponent {
  title = 'Wipro';

  // myObject = {
  //   name: "Jon Snow",
  //   age: 22,
  //   sex: "male"
  // }
  
  users: Array<any>;
  
  constructor(private http:Http, private fb: FacebookService){
    console.log('Initializing Facebook');
    
        fb.init({
          appId: '1928905587376942',
          version: 'v2.9'
        });

       
  }
  
  getLoginStatus() {

    

    this.fb.getLoginStatus()
      .then(console.log.bind(console))
      .catch(console.error.bind(console));
      
  }

 


     login() {
      
      this.fb.login()
        .then((res: LoginResponse) => {
          console.log('Logged in', res);
        })
        .catch(this.handleError);
    }

    private handleError(error) {
      console.error('Error processing action', error);
    }
    

  
  // myArr = ['one','two','three'];

  
  fb_conn=true;
  myButton=true;

  angularLogo="https://typeset-beta.imgix.net/rehost%2F2016%2F9%2F29%2F5a40855b-b555-4732-8fc9-365880725cbc.jpg";

  myEvent(event){
    console.log(event);
  }

  wall='wall-css';
  bluebut='blue-but-css';
  
  
  access_token="EAACEdEose0cBACzKX025z1YsfqSveTA69pyJkVGRFXq6kY3QxN7E2zkFwdMEEAcYZAw7tvQPS8p7kZAvaBXxWfPScoD5YTFED2OC5BamUuxsrUaMkdQVawznaLgoAuk7LQz1LVDOovOZCZAgi67rXAxZArAoxbHIjAB8PHrDBA7S1LSHq2q22VA0nOO8aq6UZD";

  
  url = "https://graph.facebook.com/me?fields=id,name,age_range,picture&access_token="+this.access_token;

  result;
  result1="";
  posts;
  name="";
  id="";
  age="";
  img_url="";

  url1="";
  ngOnInit(){

    //Create a database named "mydb":
    this.url1 = "mongodb://localhost:27017/armaan";
    
    
          
    


    

    this.http.get(this.url).map(res => res.json()).subscribe(data => {
      this.fb_conn=true;
      console.log(data);
      this.name="Welcome "+data.name;
      this.id="Your id is "+data.id;
      this.age="You are "+data.age_range.min+"years old!";
      this.img_url=data.picture.data.url;
      console.log(data.picture.data.url);
  },
  err => {
    
    this.fb_conn=false;
  });



  this.http.get("https://graph.facebook.com/me?fields=friends{name}&access_token="+this.access_token).map(res => res.json()).subscribe(data => {
    console.log(data);
    this.fb_conn=true;
},
err => {
  this.fb_conn=false;
});


console.log("................................");










   
    }

    refresh(){
      window.location.reload();
    }
  
    
    

    
    
      

    
    

  
  
    
    

}
